
// import our packages
var express = require('express');
var request = require('request');
var mongoose = require('mongoose');

// import our image model
var Image = require('../models/Image.js');

// create a router object
var giphyRouter = express.Router()

// make a route for sending the user a simple message
giphyRouter.get('/', function(req,res){
	res.json({message: "This router is working! Huzahhh!"});
});

// route for retrieving random image from Giphy
giphyRouter.get('/random', function(req,res){

	// Giphy's standard random image url
	var requestUrl = "http://api.giphy.com/v1/gifs/random?api_key=dc6zaTOxFJmzC"

	// use the request package to retrieve an image url from Giphy
	request(requestUrl, function(error, response, body){
		var imgUrl = JSON.parse(body).data.image_original_url;

		// create an object from our Image model
		var randomeGiphyImage = Image({
			image_url: imgUrl
		});

		// save the object to the database, and then send the user the image to view
		randomeGiphyImage.save(function(err){
			if(err) throw err;
			console.log("Boom! Image created!")
			res.send('<img src="' + imgUrl + '">');
		})
	})
})

module.exports = giphyRouter;