// import the mongoose package so we can use it to interact with our DB
var mongoose = require('mongoose');

// refer to mongoose's Schema object constructor as 'Schema'
var Schema = mongoose.Schema;

// create the schema, or 'structure' of our image records
var imageSchema = new Schema({
	image_url: String,
	created_at: Date
});

// before saving to the database, run this middleware to timestamp our image
imageSchema.pre('save', function(next){
	if(!this.created_at){
		var currentDate = new Date();
		this.created_at = currentDate;
	}
	next();
});

// build a model out of the schema that we can use to create new records
var Image = mongoose.model('Image', imageSchema);

// make the model object available to the rest of our application 
module.exports = Image;