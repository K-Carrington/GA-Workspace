
// import the express package, and invoke it as our application
var express = require('express');
var app = express();

// import the mongoose npm package to easily interact with a MongoDB database
var mongoose = require('mongoose');

// connect to mongo (if no db named 'giphy' is present, it will automatically create one when records are saved).
// if there's an error connecting, tell us. Otherwise tell us we've connected.
mongoose.connect('mongodb://localhost/giphy', function(err){
	if(err) throw err;
	console.log('Connected to the database! All is right in the world!');
})

// routers
var giphyRoutes = require('./routes/api.js');


// middleware
// not using any middleware here (yet)


// routes
app.get('/', function(req,res){
	res.send('<h1>Hello!</h1><h2>Go to http://localhost:3000/giphy/random to see a random image</h2><h3>This will also save the image url to the mongo database</h3>')
});

// any routes that start with '/gliphy' will invoke our giphyRoutes
app.use('/giphy', giphyRoutes);

// listen for requests on port 3000, 
// and log a message when the server's ready to take requests
app.listen(3000, function(){
	console.log('Application server is running!')
})