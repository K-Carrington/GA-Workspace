var mongoose = require('mongoose')

//create team schema
var teamSchema = new mongoose.Schema({
	name: {type: String, require: true, unique: true},
	city: String,
	color: String,
	mascot: String
})

//set team model
var Team = mongoose.model('Team', teamSchema)

module.exports = Team