var mongoose = require('mongoose')

//create our schema
var playerSchema = new mongoose.Schema({
	number: Number,
	name: {type: String, require: true, unique: true},
	team: String
})

var Player = mongoose.model('Player', playerSchema)

module.exports = Player