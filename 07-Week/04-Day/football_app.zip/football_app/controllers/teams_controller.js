var Team = require('../models/team.js')

//index function
function index(req, res) {
	Team.find({}, function(err, teams) {
		if (err) throw err
		res.json(teams)
	})
}

//create function
function create(req, res) {
	var team = new Team()
	team.name = req.body.name
	team.city = req.body.city
	team.color = req.body.color
	team.mascot = req.body.mascot

	team.save(function(err) {
		if (err) throw err
		res.json({success: true, message: "Team created!"})
	})
}

//show function
function show(req, res) {
	Team.find({name: req.params.name}, function(err, team) {
		if (err) throw err
		res.json(team)
	})
}

//update function
function update(req, res) {
	Team.findOneAndUpdate({name: req.params.name}, {city: req.body.city}, function(err ,team) {
		if (err) throw err
		res.json(team)
	})
}

//destroy function
function destroy(req, res) {
	Team.remove({name: req.params.name}, function(err) {
		if (err) throw err
		res.json({success: true, message: "Team deleted"})
	})
}

module.exports = {
	index: index,
	create: create,
	show: show,
	update: update,
	destroy: destroy
}