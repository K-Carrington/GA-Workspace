var Player = require('../models/player.js')

//index action
function index(req, res) {
	Player.find({}, function(err, players) {
		if (err) throw err
		res.json(players)
	})
}

//create action
function create(req, res) {
	var player = new Player() 
	player.number = req.body.number
	player.name = req.body.name
	player.team = req.body.team

	player.save(function(err) {
		if (err) throw err
		res.json({success: true, message: "User created!"})
	})
}

//show action
function show(req, res) {
	Player.find({name: req.params.name}, function(err, player) {
		if (err) throw err
		res.json(player)
	})
}

//update a player
function update(req, res) {
	Player.findOneAndUpdate({name: req.params.name}, {team: req.body.team}, function(err, player) {
		if (err) throw err
		res.json(player)
	})
}

//delete a player
function destroy(req, res) {
	Player.remove({name: req.params.name}, function(err) {
		if (err) throw err
		res.json({success: true, message: "Bye, Felicia!"})
	})
}

module.exports = {
	index: index,
	create: create,
	show: show,
	update: update,
	destroy: destroy
}