var express = require('express'),
	teamsController = require('../controllers/teams_controller.js'),
	teamRoutes = express.Router()

//set routes for /teams
teamRoutes.route('/')
	.get(teamsController.index)
	.post(teamsController.create)

//set routes for /teams/:name
teamRoutes.route('/:name')
	.get(teamsController.show)
	.patch(teamsController.update)
	.delete(teamsController.destroy)

module.exports = teamRoutes