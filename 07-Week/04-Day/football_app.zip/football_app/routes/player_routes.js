var playersController 	= require('../controllers/players_controller.js'),
	express				= require('express'),
	playerRoutes		= express.Router()

//set routes for /players
playerRoutes.route('/')
	.get(playersController.index)
	.post(playersController.create)

//set routes for /players/:name
playerRoutes.route('/:name')
	.get(playersController.show)
	.patch(playersController.update)
	.delete(playersController.destroy)

module.exports = playerRoutes