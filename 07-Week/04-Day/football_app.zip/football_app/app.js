var express 	= require('express'),
	app			= express(),
	bodyParser 	= require('body-parser'),
	logger		= require('morgan'),
	mongoose	= require('mongoose'),
	port 		= process.env.PORT || 3000,
	playerRoutes = require('./routes/player_routes.js'),
	teamRoutes 	= require('./routes/team_routes.js')

//establish a connection to our database
mongoose.connect('mongodb://localhost/football_app')

//set up our logger
app.use(logger('dev'))

//set up our middleware
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({extended: false}))

//create a root route
app.get('/', function(req, res) {
	res.send('Football players!')
})

//use playerRoutes for /players
app.use('/players', playerRoutes)

//use teamRoutes for /teams
app.use('/teams', teamRoutes)

//set up our server to listen on the designated port
app.listen(port)
console.log('Server started on', port)