class Movie < ActiveRecord::Base
	belongs_to :user
end
